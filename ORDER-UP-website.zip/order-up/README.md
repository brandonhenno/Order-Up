# ORDER UP

A no-build, static MVP of the daily ranking game. It uses plain HTML, CSS and JavaScript so it can be deployed free on Cloudflare Pages or GitHub Pages without installing packages.

## Run locally
Open `index.html` in a browser.

## Deploy to Cloudflare Pages
1. Create a new GitHub repository named `order-up`.
2. Upload `index.html`, `style.css`, and `app.js` to the repository root.
3. In Cloudflare, go to Workers & Pages → Create → Pages → Connect to Git.
4. Select the repository.
5. Framework preset: **None**. Build command: leave blank. Build output directory: `/` (or `.` if the UI requests it).
6. Deploy.

## Current MVP scope
- Daily five-round ranking challenge, deterministic by Europe/Dublin date.
- 60-second per-round timer and auto-submit.
- Pairwise scoring up to 500 points.
- Drag-and-drop plus move buttons.
- Untimed practice, personal history, streaks, stats, and share text.
- Local browser storage only. No accounts or true global leaderboard yet.

## Important content note
This is a playable prototype. The sample question bank is illustrative and needs a full editorial fact-check/source pass before a public competitive launch. Rankings with variable values or disputed definitions should be tightened with dated sources.
